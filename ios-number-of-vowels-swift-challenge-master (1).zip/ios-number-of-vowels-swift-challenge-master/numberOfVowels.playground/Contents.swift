/*
Challenge
"A, E, I, O, U, and sometimes Y..."

Write a function called numberOfVowels(in string: String) that returns the count of the total number of vowels in a string. Your solution should be case-insensitive, and allow for 'Y' to be included, or excluded from the count when calling the function.

Example: numberOfVowels(in: "Polly wants a cracker!", isYAVowel = true) // returns 6


*/

import UIKit

func numberOfVowels(in string: String, isYAVowel: Bool = false) -> Int {
    var number : Int = 0
    
    if isYAVowel == true {
        for letter in string {
          if letter == "A" || letter == "a" {
            number += 1
          } else if letter == "E" || letter == "e" {
            number += 1
          } else if letter == "I" || letter == "i" {
            number += 1
          } else if letter == "O" || letter == "o" {
            number += 1
          } else if letter == "U" || letter == "u" {
            number += 1
          } else if letter == "Y" || letter == "y" {
            number += 1
          }
        }
    } else {
        for letter in string {
          if letter == "A" || letter == "a" {
            number += 1
          } else if letter == "E" || letter == "e" {
            number += 1
          } else if letter == "I" || letter == "i" {
            number += 1
          } else if letter == "O" || letter == "o" {
            number += 1
          } else if letter == "U" || letter == "u" {
            number += 1
          }
        }
    }
    return number
}
    
numberOfVowels(in: "Hey I love you!")
numberOfVowels(in: "YYYYo", isYAVowel: false)
